Q1 Browser (WebView2 portable build)
=====================================

1. This package is the whole application. Keep the folder together.
2. Double-click Q1Browser.exe.
3. It uses the Microsoft Edge WebView2 runtime installed on Windows.
   If it doesn't start, install the WebView2 Runtime from Microsoft:
   https://developer.microsoft.com/microsoft-edge/webview2/

AI assistant:
  Click the AI button, open Settings, and point it to an OpenAI-compatible
  endpoint, e.g. Ollama http://127.0.0.1:11434/v1 (model llama3.2).

Source: https://github.com/tagharpro/Q1
